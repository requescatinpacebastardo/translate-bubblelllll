package com.example.cevirbalon

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.core.content.edit

// Nord esintili, sakin ve profesyonel renk paleti
object Pal {
    const val BACKGROUND = 0xFFF4F6FA.toInt()
    const val CARD = 0xFFFFFFFF.toInt()
    const val TEXT = 0xFF2E3440.toInt()
    const val MUTED = 0xFF8891A3.toInt()
    const val ACCENT = 0xFF5E81AC.toInt()
    const val ACCENT_SOFT = 0xFFD8E3F0.toInt()
    const val OK = 0xFF7FB88A.toInt()
    const val OFF_RING = 0xFFD9DEE6.toInt()
}

data class Lang(val code: String, val label: String)

object Langs {
    val list = listOf(
        Lang("en", "İngilizce"), Lang("de", "Almanca"), Lang("fr", "Fransızca"),
        Lang("es", "İspanyolca"), Lang("ru", "Rusça"), Lang("ar", "Arapça"),
        Lang("it", "İtalyanca"), Lang("pt", "Portekizce"), Lang("nl", "Felemenkçe"),
        Lang("pl", "Lehçe"), Lang("ja", "Japonca"), Lang("ko", "Korece"),
        Lang("zh", "Çince"), Lang("tr", "Türkçe")
    )
}

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var statusAcc: TextView
    private lateinit var statusBat: TextView
    private lateinit var sourceSpinner: Spinner
    private lateinit var targetSpinner: Spinner
    private lateinit var powerBtn: FrameLayout
    private lateinit var powerLabel: TextView
    private var bubbleOn = true

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(36, 32, 36, 32)
        val bg = GradientDrawable()
        bg.cornerRadius = 28f
        bg.setColor(Pal.CARD)
        l.background = bg
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 28
        l.layoutParams = lp
        return l
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Pal.TEXT)
        setPadding(0, 0, 0, 16)
    }

    private fun button(text: String, bgColor: Int, fg: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(fg)
        val bg = GradientDrawable()
        bg.cornerRadius = 20f
        bg.setColor(bgColor)
        b.background = bg
        b.setPadding(28, 20, 28, 20)
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("cevir", MODE_PRIVATE)
        bubbleOn = prefs.getBoolean("bubble_on", true)

        val root = ScrollView(this)
        root.setBackgroundColor(Pal.BACKGROUND)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, 0, 48)
        root.addView(col)

        // ---------- Hero: low-poly arka plan + büyük güç butonu ----------
        val hero = FrameLayout(this)
        val heroBg = ImageView(this)
        heroBg.setImageResource(R.drawable.bg_hero)
        heroBg.scaleType = ImageView.ScaleType.CENTER_CROP
        hero.addView(heroBg, FrameLayout.LayoutParams(-1, dp(420)))

        val heroCol = LinearLayout(this)
        heroCol.orientation = LinearLayout.VERTICAL
        heroCol.gravity = Gravity.CENTER_HORIZONTAL
        heroCol.setPadding(0, dp(72), 0, dp(28))

        val headerTitle = TextView(this).apply {
            text = "Çeviri Balonu"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        heroCol.addView(headerTitle)
        val headerSub = TextView(this).apply {
            text = "Her yerde, anında çeviri"
            textSize = 12f
            setTextColor(0xFFCBD9EA.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 0)
        }
        heroCol.addView(headerSub)

        val spacerTop = Space(this); spacerTop.layoutParams = LinearLayout.LayoutParams(-1, dp(36))
        heroCol.addView(spacerTop)

        // Büyük yuvarlak güç butonu
        val ringSize = dp(190)
        val ring = FrameLayout(this)
        ring.layoutParams = LinearLayout.LayoutParams(ringSize, ringSize).apply { gravity = Gravity.CENTER_HORIZONTAL }
        val ringBg = GradientDrawable()
        ringBg.shape = GradientDrawable.OVAL
        ringBg.setColor(0x33FFFFFF)
        ring.background = ringBg

        powerBtn = FrameLayout(this)
        val innerSize = dp(150)
        val innerLp = FrameLayout.LayoutParams(innerSize, innerSize)
        innerLp.gravity = Gravity.CENTER
        powerBtn.layoutParams = innerLp
        powerBtn.isClickable = true
        powerBtn.isFocusable = true

        val icon = ImageView(this)
        icon.setImageResource(R.mipmap.ic_launcher)
        icon.scaleType = ImageView.ScaleType.CENTER_CROP
        val iconSize = dp(96)
        val iconLp = FrameLayout.LayoutParams(iconSize, iconSize)
        iconLp.gravity = Gravity.CENTER
        icon.layoutParams = iconLp
        icon.clipToOutline = true
        icon.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, iconSize, iconSize)
            }
        }
        powerBtn.addView(icon)

        ring.addView(powerBtn)
        heroCol.addView(ring)

        val spacerMid = Space(this); spacerMid.layoutParams = LinearLayout.LayoutParams(-1, dp(20))
        heroCol.addView(spacerMid)

        powerLabel = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        }
        heroCol.addView(powerLabel)

        hero.addView(heroCol, FrameLayout.LayoutParams(-1, -2))
        col.addView(hero)

        powerBtn.setOnClickListener {
            bubbleOn = !bubbleOn
            prefs.edit { putBoolean("bubble_on", bubbleOn) }
            renderPower()
        }
        renderPower()

        // ---------- Alt içerik ----------
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(36, 32, 36, 0)
        col.addView(content)

        // Dil kartı
        val langCard = card()
        langCard.addView(title("Kaynak dil"))
        sourceSpinner = Spinner(this)
        langCard.addView(sourceSpinner)
        val sp1 = Space(this); sp1.layoutParams = LinearLayout.LayoutParams(-1, 20)
        langCard.addView(sp1)
        langCard.addView(title("Hedef dil"))
        targetSpinner = Spinner(this)
        langCard.addView(targetSpinner)
        content.addView(langCard)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Langs.list.map { it.label })
        sourceSpinner.adapter = adapter
        targetSpinner.adapter = adapter
        val savedSrc = prefs.getString("src", "tr")
        val savedTgt = prefs.getString("tgt", "en")
        sourceSpinner.setSelection(Langs.list.indexOfFirst { it.code == savedSrc }.coerceAtLeast(0))
        targetSpinner.setSelection(Langs.list.indexOfFirst { it.code == savedTgt }.coerceAtLeast(0))

        val saveBtn = button("Dilleri kaydet", Pal.ACCENT, Color.WHITE) {
            prefs.edit {
                putString("src", Langs.list[sourceSpinner.selectedItemPosition].code)
                putString("tgt", Langs.list[targetSpinner.selectedItemPosition].code)
            }
            Toast.makeText(this, "Kaydedildi. İlk kullanımda dil paketi bir kez indirilecek.", Toast.LENGTH_LONG).show()
        }
        val sp2 = Space(this); sp2.layoutParams = LinearLayout.LayoutParams(-1, 20)
        content.addView(sp2)
        content.addView(saveBtn)

        // İzin kartı
        val sp3 = Space(this); sp3.layoutParams = LinearLayout.LayoutParams(-1, 28)
        content.addView(sp3)
        val permCard = card()
        permCard.addView(title("Kurulum"))

        statusAcc = TextView(this).apply { textSize = 13f; setPadding(0, 0, 0, 12) }
        permCard.addView(statusAcc)
        permCard.addView(button("Erişilebilirlik iznini aç", Pal.ACCENT_SOFT, Pal.TEXT) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        val spBat = Space(this); spBat.layoutParams = LinearLayout.LayoutParams(-1, 16)
        permCard.addView(spBat)
        statusBat = TextView(this).apply { textSize = 13f; setPadding(0, 0, 0, 12) }
        permCard.addView(statusBat)
        permCard.addView(button("Pil kısıtlamasını kaldır (önemli)", Pal.ACCENT, Color.WHITE) {
            requestBatteryExemption()
        })
        val note = TextView(this)
        note.text = "Bu izin kapalı kalırsa telefon, çeviri balonunu arka planda kapatabilir " +
                "ve her seferinde yeniden açman gerekir."
        note.textSize = 12f
        note.setTextColor(Pal.MUTED)
        note.setPadding(0, 10, 0, 0)
        permCard.addView(note)

        val spNotif = Space(this); spNotif.layoutParams = LinearLayout.LayoutParams(-1, 20)
        permCard.addView(spNotif)
        permCard.addView(button("Bildirim iznini ver", Pal.ACCENT_SOFT, Pal.TEXT) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2)
            } else {
                Toast.makeText(this, "Bu telefonda gerekli değil.", Toast.LENGTH_SHORT).show()
            }
        })
        val note2 = TextView(this)
        note2.text = "Çeviri Balonu'nun kapanmaması için küçük, sessiz bir bildirim gösterir. " +
                "Bu bildirime dokunman gerekmez."
        note2.textSize = 12f
        note2.setTextColor(Pal.MUTED)
        note2.setPadding(0, 10, 0, 0)
        permCard.addView(note2)

        val sp4 = Space(this); sp4.layoutParams = LinearLayout.LayoutParams(-1, 20)
        permCard.addView(sp4)
        content.addView(permCard)

        val info = TextView(this)
        info.text = "Nasıl kullanılır:\n\n" +
                "1) Yukarıdan dilleri seç ve kaydet.\n" +
                "2) Erişilebilirlik iznini aç ve listede \"Çeviri Balonu\"nu bul, etkinleştir.\n" +
                "3) Ortadaki büyük butona dokunarak balonu her an aç/kapat.\n" +
                "4) Herhangi bir uygulamada yazarken balona kısa dokun, panel otomatik çeviri gösterir.\n" +
                "5) Panelde \"Kopyala\" ile çeviriyi panoya alıp yapıştırabilirsin.\n\n" +
                "Karşı tarafın mesajını çevirmek için:\n" +
                "Balona BASILI TUT (yarım saniye). Ekranda o an görünen yazılar listelenir, " +
                "her satırın yanındaki ⇄ ikonuna dokununca sadece o mesaj çevrilir.\n\n" +
                "Play Store uyumlu yol:\n" +
                "Herhangi bir yerde bir yazıyı seç, açılan menüden \"Çeviri Balonu ile çevir\"e " +
                "dokun. Bu yol hiçbir özel izin istemez."
        info.textSize = 13f
        info.setTextColor(Pal.MUTED)
        info.setLineSpacing(6f, 1f)
        val sp5 = Space(this); sp5.layoutParams = LinearLayout.LayoutParams(-1, 28)
        content.addView(sp5)
        content.addView(info)

        setContentView(root)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun renderPower() {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        if (bubbleOn) {
            d.setColor(Pal.ACCENT)
            d.setStroke(dp(3), Color.WHITE)
        } else {
            d.setColor(0x55FFFFFF)
            d.setStroke(dp(3), Pal.OFF_RING)
        }
        powerBtn.background = d
        powerBtn.elevation = dp(6).toFloat()
        powerLabel.text = if (bubbleOn) "BALON AÇIK" else "BALON KAPALI"
    }

    override fun onResume() {
        super.onResume()
        bubbleOn = prefs.getBoolean("bubble_on", true)
        renderPower()

        val on = isAccessibilityOn()
        statusAcc.text = if (on) "✅ Erişilebilirlik izni açık, balon kullanılabilir." else "⚠️ Erişilebilirlik izni kapalı."
        statusAcc.setTextColor(if (on) Pal.OK else Pal.MUTED)

        val batOk = isBatteryExempt()
        statusBat.text = if (batOk) "✅ Pil kısıtlaması kapalı, uygulama arka planda kalabilir."
            else "⚠️ Pil kısıtlaması açık, telefon uygulamayı kapatabilir."
        statusBat.setTextColor(if (batOk) Pal.OK else Pal.MUTED)
    }

    private fun isAccessibilityOn(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val list = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
        return list.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun isBatteryExempt(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun requestBatteryExemption() {
        if (isBatteryExempt()) {
            Toast.makeText(this, "Zaten açık.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}
